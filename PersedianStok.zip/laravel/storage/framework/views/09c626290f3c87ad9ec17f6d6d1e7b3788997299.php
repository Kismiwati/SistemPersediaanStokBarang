<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <style>
        table.static {
            position: relative;
            border: 1px solid #543535;
        }
    </style>
    <title>Cetak Data Barang Keluar </title>
</head>

<body>
    <div class="form-group">
        <p align="center"><b>Laporan Data Barang</b></p>

        <table class="static" align="center" rules="all" border="1px" style="width: 95%;">
            <tr>
                <th>No </th>
                <th>Jenis Barang</th>
                <th>Warna</th>
                <th>Ukuran</th>
                <th>Nama Barang</th>
                <th>Satuan</th>
                <th>Harga</th>
                <th>foto</th>
                <th>Stok</th>
                <th>Keterangan</th>
            </tr>

            <?php $__currentLoopData = $cetakPertanggal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr align="center">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($b->kategori->nama_kategori); ?></td>
                    <td><?php echo e($b->warna->warna); ?></td>
                    <td><?php echo e($b->ukuran->nama_ukuran); ?></td>
                    <td><?php echo e($b->nama_barang); ?></td>
                    <td><?php echo e($b->satuan); ?></td>
                    <td>Rp. <?php echo number_format($b->harga,0,',','.'); ?></td>
                    <td><img src="<?php echo e($b->foto); ?>" width="50"></td>
                    <td><?php echo e($b->stok); ?></td>
                    <td> <?php echo e(date_format($b->created_at, 'Y-m-d ')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\PersedianStok\resources\views\admin\app\barang\cetak-barang-pertgl.blade.php ENDPATH**/ ?>