<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <style>
        table.static {
            position: relative;
            border: 1px solid #543535;
        }
    </style>
    <title>Cetak Data Barang Keluar </title>
</head>
<body>
    <div class="form-group">
        <p align="center"><b>Laporan Data Barang Keluar</b></p>

        <table class="static" align="center" rules="all" border="1px" style="width: 95%;">
            <tr>
                <th>No.</th>
                <th>Nama Barang</th>
                <th>User</th>
                <th >Jumlah Barang</th>
                <th >Harga Satuan</th>
                <th>Keterangan</th>
                <th>Harga Total</th>
            </tr>

            <?php $__currentLoopData = $cetakPertanggal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr align="center">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($dt->barang->nama_barang); ?></td>
                    <td><?php echo e($dt->user->name); ?></td>
                    <td ><?php echo e($dt->jml_brg_keluar); ?></td>
                    <td>Rp. <?php echo number_format($dt->barang->harga,0,',','.'); ?></td>
                    <td><?php echo e(date_format($dt->created_at,"Y-m-d ")); ?></td>
                    <td>Rp. <?php echo number_format($dt->barang->harga*$dt->jml_brg_keluar,0,',','.'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr align="center">
                <td colspan="6">Total</td>
                <td>Rp. <?php echo number_format($jumlah,0,',','.'); ?></td>

            </tr>
        </table>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\PersedianStok\resources\views\admin\app\keluar\cetak-keluar-pertgl.blade.php ENDPATH**/ ?>