
<?php $__env->startSection('title', 'Table'); ?>
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
    <div id="page-wrapper">
        <div class="main-page">
            <div class="tables">
                <div class="bs-example widget-shadow" data-example-id="bordered-table">
                    <center>
                        <h2>Data Barang Masuk</h2>
                    </center>
                    <br><br>
                    <div class="content" style="text-align: right;">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <div class="card-tools">
                                    <a href="/karyawan/masuk/add" class="btn btn-info text-right">Tambah Barang</a>
                                    <a href="/karyawan/exportpdfmasuk" class="btn btn-info text-right ">Cetak PDF</a>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <br><br>
                    <table class="table table-bordered" id="example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Barang</th>
                                <th>User</th>
                                <th>Jumlah Barang Masuk</th>
                                <th>Keterangan</th>

                                

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datamsk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($m->barang->nama_barang); ?></td>
                                    <td><?php echo e($m->user->name); ?></td>
                                    <td><?php echo e($m->jml_brg_masuk); ?></td>
                                    <td><?php echo e(date_format($m->created_at, 'Y-m-d ')); ?></td>

                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('karyawan.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\karyawan\masuk\index.blade.php ENDPATH**/ ?>