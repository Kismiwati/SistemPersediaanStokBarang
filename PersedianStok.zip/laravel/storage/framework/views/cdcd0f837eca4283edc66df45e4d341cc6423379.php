<div class="main-content">
    <!--left-fixed -navigation-->
    <div class=" sidebar" role="navigation">
        <div class="navbar-collapse">
            <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
                <ul class="nav" id="side-menu">
                <li>
                    <a href="/admin/barang"><i class="fa fa-home nav_icon"></i>Dashboard</a>
                </li>
                <li>
                    <a href="/admin/brg"><i class="fa fas fa-file nav_icon"></i>Data Barang</a>
                </li>
                <li>
                    <a href="/admin/jenis"><i class="fa fa-indent nav_icon"></i>Jenis Barang</a>
                    <!-- /nav-second-level -->
                </li>
                <li>
                    <a href="/admin/warna"><i class="fa fa-map-marker nav_icon"></i>Warna</a>
                </li>
                <li>
                    <a href="/admin/ukuran"><i class="fa fa-sitemap nav_icon"></i>Ukuran</a>
                </li>
                <li >
                    <a href="/admin/masuk"><i class="fa fa-sign-in nav_icon"></i>Barang Masuk</a>
                    <!-- /nav-second-level -->
                </li>
                <li>
                    <a href="/admin/keluar"><i class="fa fa-sign-out nav_icon"></i>Barang Keluar</a>
                </li>
                
                
                <li >
                    <a href="/admin/user"><i class="fa fa-user nav_icon"></i>Manajemen Admin</a>
                </li>
            </ul>
            <!-- //sidebar-collapse -->
        </nav>
        </div>
</div><?php /**PATH C:\laragon\www\PersedianStok\resources\views\admin\component\sidebar.blade.php ENDPATH**/ ?>