
<?php $__env->startSection('title', 'Table'); ?>
<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="main-page">
            <div class="row-one">
                <div class="col-md-4 widget">
                    <div class="stats-left ">
                        <h5>Total Harga Barang</h5>
                        <h4>Masuk</h4>
                    </div>
                    <div class="stats-right">
                        <label><?php echo e(DB::table('brg_masuk')->sum('jml_brg_masuk')); ?></label>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="col-md-4 widget states-mdl">
                    <div class="stats-left">
                        <h5>Total Harga Barang</h5>
                        <h4>Keluar</h4>
                    </div>
                    <div class="stats-right">
                        <label><?php echo e(DB::table('brg_keluar')->sum('jml_brg_keluar')); ?></label>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="row calender widget-shadow">
                <h4 class="title">Calender</h4>
                <div class="cal1">

                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\admin\app\index.blade.php ENDPATH**/ ?>