
<?php $__env->startSection('title','Form'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div id="page-wrapper">
        <div class="main-page">
            <div class="forms">
                <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                    <div class="form-body">
                        <form action="<?php echo e(url('/admin/keluar/createBarang/')); ?>" role="form" method="POST">
                            <?php echo csrf_field(); ?> 
                            
                                <div class="form-group"> 
                                    <label for="id_barang ">Barang</label> 
                                    <select name="id_barang"  class="custom-select form-control">
                                        <option value="Pilih Barang">Pilih Barang</option>
                                        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($b->id); ?>" ><?php echo e($b->nama_barang); ?> - (<?php echo e($b->kategori->nama_kategori); ?>, <?php echo e($b->warna->warna); ?>, <?php echo e($b->ukuran->nama_ukuran); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group"> 
                                    <label for="id_user ">User</label> 
                                    <input readonly value="<?php echo e(session('name')); ?>" name="id_user" type="text" class="form-control" id="id_user" placeholder=""> 
                                    
                                </div>
                                 <div class="form-group"> 
                                    <label for="jml_brg_keluar">Jumlah Barang Keluar</label> 
                                    <input min="0" name="jml_brg_keluar" type="number" class="form-control" id="jml_brg_keluar" placeholder="Masukkan Jumlah Barang Keluar"> 
                                </div> 
                                
                                <button type="submit" class="btn btn-default">Simpan</button> </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\admin\app\keluar\form.blade.php ENDPATH**/ ?>