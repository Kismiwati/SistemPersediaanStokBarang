
<?php $__env->startSection('title', 'Table'); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div id="page-wrapper">
        <div class="main-page">
            <div class="tables mt-5">
                <div class="bs-example widget-shadow " data-example-id="bordered-table">
                    <center><h2>Data Barang</h2></center>
                    <br><br>
                    <div class="content" style="text-align: right;">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <div class="card-tools">
                                    <a href="/karyawan/barang/add" class="btn btn-info text-right">Tambah Barang
                                        
                                    </a>
                                    
                                        
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br><br>
                    <table class="table table-bordered" id="example" mt-5>
                        <thead>
                            <tr>
                                <th>No </th>
                                <th>Jenis Barang</th>
                                <th>Warna</th>
                                <th>Ukuran</th>
                                <th>Nama Barang</th>
                                <th>Satuan</th>
                                <th>Harga</th>
                                <th>foto</th>
                                <th>Stok</th>
                                <th>Keterangan</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $brg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($b->kategori->nama_kategori); ?></td>
                                    <td><?php echo e($b->warna->warna); ?></td>
                                    <td><?php echo e($b->ukuran->nama_ukuran); ?></td>
                                    <td><?php echo e($b->nama_barang); ?></td>
                                    <td><?php echo e($b->satuan); ?></td>
                                    <td>Rp. <?php echo number_format($b->harga,0,',','.'); ?></td>
                                    <td><img src="<?php echo e($b->foto); ?>"  width="50"></td>
                                    <td><?php echo e($b->stok); ?></td>
                                    <td> <?php echo e(date_format($b->created_at,"Y-m-d ")); ?></td>
                                    <td>
                                        <a href="/karyawan/editBarang/<?php echo e($b->id); ?>" class="btn btn-success">Edit</a>
                                        <br><br>
                                        <button onclick="onDelete(<?php echo e($b->id); ?>)" class="btn btn-danger">Hapus</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
    <script>
        
        function onDelete(id) {
            Swal.fire({
                title: 'apakah kamu yakin                                                                                                       ?',
                text: "Anda tidak akan dapat mengembalikan ini!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                window.location.href = '/karyawan/deleteBarang/'+id;
                if (result.isConfirmed) {
                    Swal.fire(
                        'Dihapus!',
                        'File Anda telah dihapus.',
                        'Berhasil'
                    )
                }
            })
        }
    </script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('karyawan.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views/karyawan/app/index.blade.php ENDPATH**/ ?>