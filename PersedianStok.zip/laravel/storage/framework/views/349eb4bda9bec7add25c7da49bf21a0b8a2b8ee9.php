
<?php $__env->startSection('title','Form'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div id="page-wrapper">
        <div class="main-page">
            <div class="forms">
                <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                    <div class="form-title">
                        <h4>Jenis Barang :</h4>
                    </div>
                    <div class="form-body">
                        <form action="<?php echo e(url('/karyawan/kategori/create/')); ?>" role="form" method="POST">
                            <?php echo csrf_field(); ?> 
                            <div class="form-group"> 
                                <label for="nama_kategori ">Jenis Barang</label> 
                                <input name="nama_kategori" type="text" class="form-control" id="nama_kategori " placeholder="Masukkan Jenis Barang"> 
                            </div>
                            <button type="submit" class="btn btn-info">Simpan</button>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('karyawan.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\karyawan\kategori\form.blade.php ENDPATH**/ ?>