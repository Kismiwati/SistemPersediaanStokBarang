<div class=" sidebar" role="navigation ">
    <div class="navbar-collapse">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
            <ul class="nav" id="side-menu">
                <li>
                    <a href="/karyawan/barangs"><i class="fa fa-home nav_icon"></i>Dashboard</a>
                </li>
                
                <li>
                    <a href="/karyawan/kategori"><i class="fa fa-indent nav_icon"></i>Jenis Barang</a>
                    <!-- /nav-second-level -->
                </li>
                <li>
                    <a href="/karyawan/dataBarang"><i class="fa fas fa-file nav_icon"></i>Data Barang</a>
                </li>
                <li>
                    <a href="/karyawan/warna"><i class="fa fa-map-marker nav_icon"></i>Warna</a>
                </li>
                <li>
                    <a href="/karyawan/ukuran"><i class="fa fa-sitemap nav_icon"></i>Ukuran</a>
                </li>
                <li >
                    <a href="/karyawan/masuk"><i class="fa fa-sign-in nav_icon"></i>Barang Masuk</a>
                    <!-- /nav-second-level -->
                </li>
                <li>
                    <a href="/karyawan/keluar"><i class="fa fa-sign-out nav_icon"></i>Barang Keluar</a>
                </li>
                </ul>
            <!-- //sidebar-collapse -->
        </nav>
    </div>
</div>

<?php /**PATH C:\laragon\www\PersedianStok\resources\views\karyawan\komponen\sidebar.blade.php ENDPATH**/ ?>