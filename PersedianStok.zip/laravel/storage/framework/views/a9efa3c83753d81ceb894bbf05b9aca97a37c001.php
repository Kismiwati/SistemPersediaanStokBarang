
<?php $__env->startSection('title','Form'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div id="page-wrapper">
        <div class="main-page">
            <div class="forms">
                <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                    <div class="form-body">
                        <form action="<?php echo e(url('/karyawan/updateBarang/'.$brg->id)); ?>" role="form" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 

                            <div class="form-group">
                                <label for="id">Kode Barang</label>
                                <input readonly value="<?php echo e($brg->id); ?>" type="text" name="id" class="form-control" id="id"  placeholder="">
                            </div>
                                <div class="form-group"> 
                                    <label for="id_kategori ">Kategori</label> 
                                    <select readonly name="id_kategori"  class="custom-select form-control">
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id); ?>" ><?php echo e($k->nama_kategori); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group"> 
                                    <label for="id_warna">Warna</label> 
                                    <input readonly value="<?php echo e($brg->id_warna); ?>" name="id_warna" type="text " class="form-control" id="id_warna " > 
                                    
                                </div>
                                <div class="form-group"> 
                                    <label for="id_ukuran ">Ukuran</label> 
                                    <input readonly value="<?php echo e($brg->id_ukuran); ?>" name="id_ukuran" type="text " class="form-control" id="id_ukuran " > 
                                
                                    
                                </div>
                                <div class="form-group"> 
                                    <label for="nama_barang ">Nama Barang</label> 
                                    <input value="<?php echo e($brg->nama_barang); ?>" name="nama_barang" type="text " class="form-control" id="nama_barang " placeholder="Masukkan Nama Barang"> 
                                </div>
                                <div class="form-group"> 
                                    <label for="satuan ">Satuan</label> 
                                    <input value="<?php echo e($brg->satuan); ?>" name="satuan" type="text " class="form-control" id="satuan " placeholder="Masukkan Nama Barang"> 
                                </div>
                                <div class="form-group"> 
                                    <label for="harga ">Harga</label> 
                                    <input value="<?php echo e($brg->harga); ?>" name="harga" type="text " class="form-control" id="harga " placeholder="Masukkan Harga Barang"> 
                                </div>
                                <div class="form-group">
                                    <label for="foto" class="form-label">Gambar</label>
                                    <img src="<?php echo e($brg->foto); ?>" width="100">
                                    <input value="<?php echo e($brg->foto); ?>" name="foto" class="form-control" id="foto" type="file">
                                </div>
                                <button type="submit" onclick="onEdit()" class="btn btn-default">Submit</button> 
                            </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function onEdit(id){
    Swal.fire({
    position: 'top-end',
    icon: 'success',
    title: 'Your work has been saved',
    showConfirmButton: false,
    timer: 1500
    })
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('karyawan.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\karyawan\barang\formEdit.blade.php ENDPATH**/ ?>