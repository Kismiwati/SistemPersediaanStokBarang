
<?php $__env->startSection('title', 'Table'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function(){
    $('#example').DataTable();
    });
</script>
<div id="page-wrapper">
    <div class="main-page">
        <div class="tables">
<div class="bs-example widget-shadow" data-example-id="bordered-table"> 
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        	<hr>
    </head>
    </html>
    <center><h2>Laporan</h2></center>
    <table class="table table-bordered" id="example"> 
        <thead>
            <tr>
                <th>No </th>
                <th>Id </th>
                <th>Jenis Barang</th>
                <th>Nama Barang</th>
                <th>Ukuran</th>
                <th>Warna</th>
                <th>Harga</th>
                <th>Jumlah Barang</th>
                </tr>
        </thead>
    <tbody>
        <?php $__currentLoopData = $brg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($b->id); ?></td>
            <td><?php echo e($b->id_kategori); ?></td>
            <td><?php echo e($b->nama_barang); ?></td>
            <td><?php echo e($b->ukuran); ?></td>
            <td><?php echo e($b->warna); ?></td>
            <td>Rp. <?php echo number_format($b->harga,0,',','.'); ?></td>
            <td><?php echo e($b->stok); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\admin\app\laporan.blade.php ENDPATH**/ ?>