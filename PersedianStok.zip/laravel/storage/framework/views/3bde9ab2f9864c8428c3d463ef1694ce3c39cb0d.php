

<?php $__env->startSection('content'); ?>
<table border="1">
    <tr>
        <td>ID :</td><td><?php echo e($data['id']); ?></td>
    </tr>
    <tr>
        <td>Name :</td><td> <?php echo e($data['name']); ?></td>
    </tr>
</table>
   <h1> Selamat Datang !!</h1>
   <a href="/logout" class="btn btn-danger">Logout</a>
 <?php $__env->stopSection(); ?>       
<?php echo $__env->make('login.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\login\home.blade.php ENDPATH**/ ?>