
<?php $__env->startSection('title','Form'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div id="page-wrapper">
        <div class="main-page">
            <div class="forms">
                <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                    <div class="form-body">
                        <form action="<?php echo e(url('/admin/barang/createBarang/')); ?>" role="form" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 
                                <div class="form-group"> 
                                    <label for="id_kategori ">Kategori</label> 
                                    
                                    <select name="id_kategori"  class="custom-select form-control">
                                        <option value="Pilih Kategori">Pilih Kategori</option>
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($a->id); ?>" ><?php echo e($a->nama_kategori); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group"> 
                                    <label for="id_warna ">Warna</label> 
                                    
                                    <select name="id_warna"  class="custom-select form-control">
                                        <option value="Pilih Warna">Pilih Warna</option>
                                        <?php $__currentLoopData = $warna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($w->id); ?>" ><?php echo e($w->warna); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group"> 
                                    <label for="id_ukuran ">Ukuran</label> 
                                    
                                    <select name="id_ukuran"  class="custom-select form-control">
                                        <option value="Pilih Ukuran">Pilih Ukuran</option>
                                        <?php $__currentLoopData = $ukuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($u->id); ?>" ><?php echo e($u->nama_ukuran); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group"> 
                                    <label for="nama_barang ">Nama Barang</label> 
                                    <input name="nama_barang" type="text " class="form-control" id="nama_barang " placeholder="Nama Barang"> 
                                </div>
                                <div class="form-group"> 
                                    <label for="satuan ">Satuan</label> 
                                    <input name="satuan" type="text " class="form-control" id="satuan " placeholder=""> 
                                </div>
                                <div class="form-group"> 
                                    <label for="harga ">Harga</label> 
                                    <input name="harga" type="text " class="form-control" id="harga " placeholder=""> 
                                </div>
                                <div class="form-group">
                                    <label for="foto" class="form-label">Gambar</label>
                                    <input name="foto" class="form-control" id="foto" type="file">
                                </div>
                                
                                <button type="submit" class="btn btn-default">Simpan</button> 
                            </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PersedianStok\resources\views\admin\app\barang\form.blade.php ENDPATH**/ ?>