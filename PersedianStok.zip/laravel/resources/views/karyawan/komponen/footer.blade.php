<div class="footer">
    <p>&copy; 2023 Sistem Informasi Persedian Stok Pakain | Design by kismi <a href="https://w3layouts.com/"
            target="_blank">w3layouts</a></p>
</div>